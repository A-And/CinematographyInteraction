/*
The MIT License (MIT)

Copyright (c) 2016 British Broadcasting Corporation.
This software is provided by Lancaster University by arrangement with the BBC.

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
*/

#include "MicroBit.h"
#include "MicroBitUARTService.h"
#include "Adafruit_PWMServoDriver.h"

MicroBit uBit;
MicroBitUARTService *uart;
Adafruit_PWMServoDriver *servoD;

// Servo movement vector
int vectorLength = 6;
int pinNum = vectorLength /2;
int servoMin = 110;
int servoMax = 540;
int currentAngle = 0;

void setServoAngle(int servoIndex, int angle){
    float multiplier = ((float)(servoMax - servoMin))/180.0;
    float freq = servoMin + angle * multiplier;
    int freqI = std::floor(freq + 0.5);
    servoD->setPWM(servoIndex, 0, std::max(std::min(freqI, servoMax), servoMin));
    
}

void onConnected(MicroBitEvent e){
    uBit.display.print("C");   
    
    uint8_t *xyVector = new uint8_t[vectorLength]; 
    while(true){
        uBit.sleep(100);
         uart->read(xyVector, vectorLength); 
        for(int i =0; i < vectorLength - 1; i+=2){
            uBit.io.pin[xyVector[i]].setServoValue(xyVector[i+1]);
            setServoAngle(xyVector[i], xyVector[i+1]);
        } 
    } 
}

void onDisconnected(MicroBitEvent e){
    uBit.display.print("D");    
}

void initServo(int pinNum){
    
        uBit.io.pin[pinNum].setAnalogPeriod(20);
        uBit.io.pin[pinNum].setAnalogValue(90);
        uBit.sleep(80);
        
        uBit.io.pin[pinNum].setAnalogPeriod(20);
        uBit.io.pin[pinNum].setAnalogValue(90);
        uBit.sleep(80);
}

void onButtonA(MicroBitEvent e){
        if(e.value == MICROBIT_BUTTON_EVT_DOWN){
            setServoAngle(1, currentAngle);
            uBit.sleep(50);
            currentAngle = currentAngle == 180? 0: currentAngle + 10;
        }
    
}


void onButtonB(MicroBitEvent e){
        if(e.value == MICROBIT_BUTTON_EVT_DOWN){
            setServoAngle(1, currentAngle);
            uBit.sleep(50);
            currentAngle = currentAngle == 0? 180: currentAngle - 10;
        }
}


int main()
{
    // Initialise the micro:bit runtime.
    uBit.init();
    uart = new MicroBitUARTService(*uBit.ble, 32, 32); 
       
    uBit.messageBus.listen(MICROBIT_ID_BLE, MICROBIT_BLE_EVT_CONNECTED, onConnected);
    uBit.messageBus.listen(MICROBIT_ID_BLE, MICROBIT_BLE_EVT_DISCONNECTED, onDisconnected); 
    uBit.messageBus.listen(MICROBIT_ID_BUTTON_A, MICROBIT_EVT_ANY, onButtonA);
    uBit.messageBus.listen(MICROBIT_ID_BUTTON_B, MICROBIT_EVT_ANY, onButtonB);

    for(int i = 0; i < pinNum; i++) initServo(i);
        uBit.display.print("I");    
        uBit.display.print("W");    
    
    servoD = new Adafruit_PWMServoDriver(I2C_SDA0, I2C_SCL0);
    servoD->begin();
    servoD->setPWMFreq(50);
   
    // If main exits, there may still be other fibers running or registered event handlers etc.
    // Simply release this fiber, which will mean we enter the scheduler. Worse case, we then
    // sit in the idle task forever, in a power efficient sleep.
    release_fiber();
    
    return 0;
}

